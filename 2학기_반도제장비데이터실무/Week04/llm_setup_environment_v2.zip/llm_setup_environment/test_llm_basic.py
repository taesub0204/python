"""
==============================================
 LLM Hands-On 환경 테스트 스크립트
 - CUDA / PyTorch 확인
 - Transformers 토크나이저 테스트
 - 소형 모델로 텍스트 생성 테스트
==============================================
"""

import sys

# ── 0. Python 버전 확인 ──────────────────────────
print("=" * 55)
print(" 🐍 Step 0: Python 버전 확인")
print("=" * 55)
print(f"  Python : {sys.version}")
print()

# ── 1. PyTorch & CUDA 확인 ───────────────────────
print("=" * 55)
print(" 🔥 Step 1: PyTorch & CUDA 확인")
print("=" * 55)
try:
    import torch
    print(f"  PyTorch  : {torch.__version__}")
    print(f"  CUDA 사용: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"  GPU 이름 : {torch.cuda.get_device_name(0)}")
        print(f"  VRAM     : {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    else:
        print("  ⚠️  CUDA GPU가 감지되지 않았습니다. CPU 모드로 진행합니다.")
    print("  ✅ PyTorch 정상")
except ImportError:
    print("  ❌ PyTorch가 설치되지 않았습니다. setup_environment.bat을 먼저 실행하세요.")
    sys.exit(1)
print()

# ── 2. 주요 패키지 Import 확인 ───────────────────
print("=" * 55)
print(" 📦 Step 2: 주요 패키지 Import 확인")
print("=" * 55)

packages = {
    "transformers": "transformers",
    "accelerate": "accelerate",
    "datasets": "datasets",
    "peft": "peft",
    "trl": "trl",
    "huggingface_hub": "huggingface_hub",
    "openai": "openai",
    "langchain": "langchain",
    "numpy": "numpy",
    "pandas": "pandas",
    "matplotlib": "matplotlib",
}

all_ok = True
for display_name, module_name in packages.items():
    try:
        mod = __import__(module_name)
        ver = getattr(mod, "__version__", "?")
        print(f"  ✅ {display_name:20s} v{ver}")
    except ImportError:
        print(f"  ❌ {display_name:20s} 설치 안 됨")
        all_ok = False

if not all_ok:
    print("\n  ⚠️  일부 패키지가 누락되었습니다. requirements.txt를 다시 설치하세요.")
print()

# ── 3. 토크나이저 기초 테스트 ────────────────────
print("=" * 55)
print(" 🔤 Step 3: 토크나이저 기초 테스트")
print("=" * 55)
try:
    from transformers import AutoTokenizer

    model_id = "gpt2"
    print(f"  모델: {model_id}")
    tokenizer = AutoTokenizer.from_pretrained(model_id)

    text = "Hello, LLM world!"
    tokens = tokenizer.tokenize(text)
    ids = tokenizer.encode(text)
    decoded = tokenizer.decode(ids)

    print(f"  원본 텍스트 : {text}")
    print(f"  토큰 목록   : {tokens}")
    print(f"  토큰 ID     : {ids}")
    print(f"  디코딩 결과 : {decoded}")
    print("  ✅ 토크나이저 정상")
except Exception as e:
    print(f"  ❌ 토크나이저 테스트 실패: {e}")
print()

# ── 4. 텍스트 생성 테스트 (GPT-2 소형 모델) ─────
print("=" * 55)
print(" 💬 Step 4: 텍스트 생성 테스트 (GPT-2)")
print("=" * 55)
try:
    from transformers import pipeline

    device = 0 if torch.cuda.is_available() else -1
    device_label = "GPU" if device == 0 else "CPU"
    print(f"  디바이스: {device_label}")
    print(f"  모델 로딩 중... (최초 실행 시 다운로드)")

    generator = pipeline("text-generation", model="gpt2", device=device)
    result = generator(
        "Artificial Intelligence is",
        max_new_tokens=30,
        do_sample=True,
        temperature=0.7,
        num_return_sequences=1,
    )
    generated = result[0]["generated_text"]
    print(f"  프롬프트    : 'Artificial Intelligence is'")
    print(f"  생성 결과   : '{generated}'")
    print("  ✅ 텍스트 생성 정상")
except Exception as e:
    print(f"  ❌ 텍스트 생성 테스트 실패: {e}")
print()

# ── 5. 간단한 Tensor 연산 테스트 ─────────────────
print("=" * 55)
print(" 🧮 Step 5: GPU Tensor 연산 테스트")
print("=" * 55)
try:
    if torch.cuda.is_available():
        a = torch.randn(1000, 1000, device="cuda")
        b = torch.randn(1000, 1000, device="cuda")

        # warmup
        _ = a @ b
        torch.cuda.synchronize()

        import time
        start = time.perf_counter()
        for _ in range(100):
            c = a @ b
        torch.cuda.synchronize()
        elapsed = time.perf_counter() - start

        print(f"  1000×1000 행렬 곱셈 100회: {elapsed*1000:.1f} ms")
        print(f"  결과 shape: {c.shape}, dtype: {c.dtype}")
        print("  ✅ GPU 연산 정상")
    else:
        a = torch.randn(500, 500)
        b = torch.randn(500, 500)
        c = a @ b
        print(f"  500×500 CPU 행렬 곱셈 결과: shape={c.shape}")
        print("  ✅ CPU 연산 정상 (GPU 없음)")
except Exception as e:
    print(f"  ❌ Tensor 연산 테스트 실패: {e}")
print()

# ── 결과 요약 및 인터랙티브 Q&A ────────────────────────────────────
print("=" * 55)
print(" 🎉 모든 테스트 완료!")
print("=" * 55)
print("  이제 Jupyter Notebook에서 실습을 시작할 수 있습니다.")
print("  VS Code에서 커널을 'LLM Hands-On (Win CUDA)'로 선택하세요.")
print()

# Initialize generator once for the chat loop with clean output
try:
    from transformers import pipeline
    device = 0 if torch.cuda.is_available() else -1
    # return_full_text=False prevents echoing the input prompt in the generated text
    generator = pipeline("text-generation", model="gpt2", device=device, return_full_text=False)
except Exception as e:
    print(f"⚠️  채팅용 모델 초기화 실패: {e}")
    generator = None

def chat_loop():
    if generator is None:
        print("채팅 기능을 사용할 수 없습니다.")
        return
    print("🤖 무한 Q&A 모드 시작. 종료하려면 'exit' 혹은 빈 입력을 입력하세요.")
    while True:
        try:
            user_input = input('\n🧑‍💻 질문: ').strip()
        except (EOFError, KeyboardInterrupt):
            print("\n🛑 종료합니다.")
            break
        if not user_input or user_input.lower() == 'exit':
            print("🛑 종료합니다.")
            break
        try:
            # Generate response without returning the full prompt
            result = generator(user_input, max_new_tokens=80, do_sample=True, temperature=0.7, num_return_sequences=1)
            response = result[0]["generated_text"].strip()
            print(f"🤖 답변: {response}")
        except Exception as e:
            print(f"⚠️  답변 생성 오류: {e}")

chat_loop()