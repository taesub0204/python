@echo off
setlocal

cd /d "%~dp0"

echo.
echo ==================================================
echo   LLM Hands-On Environment Auto Setup
echo ==================================================
echo.

set PYTHON_EXE=

rem [1] py launcher - auto picks latest Python 3
py -3 --version >nul 2>&1
if %errorlevel% equ 0 (
    set PYTHON_EXE=py -3
    goto :found
)

rem [2] py -3.14
py -3.14 --version >nul 2>&1
if %errorlevel% equ 0 (
    set PYTHON_EXE=py -3.14
    goto :found
)

rem [3] py -3.13
py -3.13 --version >nul 2>&1
if %errorlevel% equ 0 (
    set PYTHON_EXE=py -3.13
    goto :found
)

rem [4] py -3.12
py -3.12 --version >nul 2>&1
if %errorlevel% equ 0 (
    set PYTHON_EXE=py -3.12
    goto :found
)

rem [5] py -3.11
py -3.11 --version >nul 2>&1
if %errorlevel% equ 0 (
    set PYTHON_EXE=py -3.11
    goto :found
)

rem [6] py -3.10
py -3.10 --version >nul 2>&1
if %errorlevel% equ 0 (
    set PYTHON_EXE=py -3.10
    goto :found
)

rem [7] python
python --version >nul 2>&1
if %errorlevel% equ 0 (
    set PYTHON_EXE=python
    goto :found
)

rem [8] python3
python3 --version >nul 2>&1
if %errorlevel% equ 0 (
    set PYTHON_EXE=python3
    goto :found
)

rem [9] direct path scan
if exist "%LOCALAPPDATA%\Programs\Python\Python314\python.exe" (
    set PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python314\python.exe
    goto :found
)
if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" (
    set PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python313\python.exe
    goto :found
)
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
    set PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe
    goto :found
)
if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
    set PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python311\python.exe
    goto :found
)
if exist "%LOCALAPPDATA%\Programs\Python\Python310\python.exe" (
    set PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python310\python.exe
    goto :found
)
if exist "C:\Python314\python.exe" (
    set PYTHON_EXE=C:\Python314\python.exe
    goto :found
)
if exist "C:\Python313\python.exe" (
    set PYTHON_EXE=C:\Python313\python.exe
    goto :found
)

rem --- Python not found ---
echo [ERROR] Python 3.10 or higher was not found.
echo.
echo   Install from: https://www.python.org/downloads/
echo   Check "Add Python to PATH" during install.
echo.
pause
exit /b 1

:found
echo [OK] Using Python: %PYTHON_EXE%
echo.

rem --- pip check ---
%PYTHON_EXE% -m pip --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [WARN] pip not found. Trying ensurepip...
    %PYTHON_EXE% -m ensurepip --upgrade >nul 2>&1
)

rem --- script check ---
if not exist "setup_environment.py" (
    echo [ERROR] setup_environment.py not found in current folder.
    echo         Make sure this bat file is in the same folder.
    echo.
    pause
    exit /b 1
)

rem --- run ---
echo [INFO] Launching setup_environment.py ...
echo.
%PYTHON_EXE% setup_environment.py
set EXIT_CODE=%errorlevel%

echo.
if %EXIT_CODE% equ 0 (
    echo ==================================================
    echo   Setup completed successfully!
    echo ==================================================
) else (
    echo ==================================================
    echo   Setup finished with errors. Check setup_log.txt
    echo ==================================================
)

echo.
pause
exit /b %EXIT_CODE%
