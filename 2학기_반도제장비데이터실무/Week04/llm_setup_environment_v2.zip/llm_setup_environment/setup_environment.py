"""
setup_environment.py  –  LLM Hands-On 환경 자동 설치 스크립트 (강화판)

방어 로직 목록:
  - Python 버전 사전 검증 (3.10+)
  - NVIDIA GPU / CUDA 버전 자동 감지 → 적절한 PyTorch wheel 선택
  - CPU-only 폴백 지원
  - venv 재생성 vs 재사용 로직
  - 네트워크 다운로드 재시도 (3회)
  - 이미 다운로드된 바이너리 스킵
  - pip 설치 실패 시 패키지별 재시도
  - 경로 내 한글/공백 처리
  - 단계별 에러 격리 및 진행 리포트
  - 최종 검증 단계 + 요약 보고서
"""

import os
import sys
import subprocess
import urllib.request
import urllib.error
import zipfile
import io
import re
import shutil
import time
import platform
import json
from pathlib import Path

# ── 상수 ────────────────────────────────────────────────────────────────────

PROJECT_DIR = Path(os.path.dirname(os.path.abspath(__file__)))
VENV_DIR    = PROJECT_DIR / "venv_win"
BIN_DIR     = PROJECT_DIR / "bin"
PYTHON_VENV = VENV_DIR / "Scripts" / "python.exe"
PIP_VENV    = VENV_DIR / "Scripts" / "pip.exe"
LOG_FILE    = PROJECT_DIR / "setup_log.txt"

LLAMA_BASE = "https://github.com/ggml-org/llama.cpp/releases/download/b10775"
LLAMA_ASSETS = {
    "cuda124": {
        "dlls": f"{LLAMA_BASE}/cudart-llama-bin-win-cuda-12.4-x64.zip",
        "exe":  f"{LLAMA_BASE}/llama-b10775-bin-win-cuda-12.4-x64.zip",
    },
    "cuda118": {
        "dlls": f"{LLAMA_BASE}/cudart-llama-bin-win-cuda-11.8-x64.zip",
        "exe":  f"{LLAMA_BASE}/llama-b10775-bin-win-cuda-11.8-x64.zip",
    },
    "cpu": {
        "exe":  f"{LLAMA_BASE}/llama-b10775-bin-win-noavx-x64.zip",
    },
}

PYTORCH_INDICES = {
    "cuda124": "https://download.pytorch.org/whl/cu124",
    "cuda118": "https://download.pytorch.org/whl/cu118",
    "cpu":     "https://download.pytorch.org/whl/cpu",
}

DOWNLOAD_TIMEOUT = 120   # seconds
DOWNLOAD_RETRIES = 3
RETRY_DELAY      = 5     # seconds

# ── 로깅 ────────────────────────────────────────────────────────────────────

_log_fh = None

def init_log():
    global _log_fh
    try:
        _log_fh = open(LOG_FILE, "w", encoding="utf-8")
        _log_fh.write(f"=== Setup Log  {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n\n")
    except Exception:
        pass  # 로그 실패는 치명적이지 않음

def log(msg: str):
    print(msg)
    if _log_fh:
        try:
            _log_fh.write(msg + "\n")
            _log_fh.flush()
        except Exception:
            pass

def section(title: str):
    bar = "─" * 52
    log(f"\n{bar}")
    log(f"  {title}")
    log(bar)

# ── 시스템 정보 수집 ──────────────────────────────────────────────────────────

def check_python_version() -> bool:
    major, minor = sys.version_info[:2]
    log(f"[CHECK] Python {major}.{minor}.{sys.version_info[2]} ({platform.architecture()[0]})")
    if major < 3 or (major == 3 and minor < 10):
        log("[ERROR] Python 3.10 or higher is required.")
        log("        Download: https://www.python.org/downloads/")
        return False
    return True

def detect_cuda_version() -> str:
    """
    nvidia-smi로 CUDA 버전을 감지한다.
    반환값: 'cuda124' | 'cuda118' | 'cpu'
    """
    # nvidia-smi 경로 후보
    smi_candidates = [
        "nvidia-smi",
        r"C:\Windows\System32\nvidia-smi.exe",
        r"C:\Program Files\NVIDIA Corporation\NVSMI\nvidia-smi.exe",
    ]
    for smi in smi_candidates:
        try:
            result = subprocess.run(
                [smi, "--query-gpu=driver_version", "--format=csv,noheader"],
                capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                # nvidia-smi 출력에서 CUDA 버전 확인
                smi_out = subprocess.run(
                    [smi], capture_output=True, text=True, timeout=10
                ).stdout
                m = re.search(r"CUDA Version:\s*(\d+)\.(\d+)", smi_out)
                if m:
                    major, minor = int(m.group(1)), int(m.group(2))
                    log(f"[INFO] NVIDIA driver detected. CUDA Runtime: {major}.{minor}")
                    if major >= 12:
                        return "cuda124"
                    elif major == 11:
                        return "cuda118"
                    else:
                        log("[WARNING] Very old CUDA (<11). Falling back to CPU mode.")
                        return "cpu"
                # CUDA 버전 파싱 실패 → 드라이버는 있으니 최신 가정
                log("[INFO] NVIDIA GPU detected (CUDA version unclear). Assuming CUDA 12.x.")
                return "cuda124"
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue

    log("[INFO] No NVIDIA GPU detected (nvidia-smi not found). Using CPU mode.")
    return "cpu"

def check_disk_space(path: Path, required_gb: float = 10.0) -> bool:
    try:
        usage = shutil.disk_usage(path)
        free_gb = usage.free / (1024 ** 3)
        log(f"[CHECK] Disk free space: {free_gb:.1f} GB (required ≥ {required_gb} GB)")
        if free_gb < required_gb:
            log(f"[WARNING] Low disk space! Setup may fail.")
            return False
        return True
    except Exception as e:
        log(f"[WARNING] Could not check disk space: {e}")
        return True  # 확인 불가 시 계속 진행

# ── 명령 실행 ────────────────────────────────────────────────────────────────

def run_cmd(cmd, check=True, capture=False, timeout=None):
    if isinstance(cmd, list):
        display = " ".join(f'"{c}"' if " " in str(c) else str(c) for c in cmd)
    else:
        display = cmd
    log(f"\n[RUN] {display}")
    try:
        kwargs = dict(
            shell=isinstance(cmd, str),
            check=False,
            timeout=timeout,
        )
        if capture:
            kwargs["capture_output"] = True
            kwargs["text"] = True
        res = subprocess.run(cmd, **kwargs)
        if check and res.returncode != 0:
            log(f"[ERROR] Command returned exit code {res.returncode}")
        return res
    except subprocess.TimeoutExpired:
        log(f"[ERROR] Command timed out after {timeout}s")
        raise
    except Exception as e:
        log(f"[ERROR] Failed to run command: {e}")
        raise

# ── 네트워크 다운로드 ─────────────────────────────────────────────────────────

def download_with_retry(url: str, retries: int = DOWNLOAD_RETRIES) -> bytes:
    for attempt in range(1, retries + 1):
        try:
            log(f"[DOWNLOAD] Attempt {attempt}/{retries}: {url}")
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=DOWNLOAD_TIMEOUT) as resp:
                total = int(resp.headers.get("Content-Length", 0))
                data = bytearray()
                chunk = 1024 * 64
                while True:
                    block = resp.read(chunk)
                    if not block:
                        break
                    data.extend(block)
                    if total:
                        pct = len(data) * 100 // total
                        print(f"\r  Progress: {pct:3d}% ({len(data)//1024//1024} MB / {total//1024//1024} MB)", end="", flush=True)
                print()
            log(f"[OK] Downloaded {len(data)//1024//1024} MB")
            return bytes(data)
        except urllib.error.HTTPError as e:
            log(f"[WARNING] HTTP {e.code}: {e.reason}")
        except urllib.error.URLError as e:
            log(f"[WARNING] Network error: {e.reason}")
        except Exception as e:
            log(f"[WARNING] Unexpected error: {e}")
        if attempt < retries:
            log(f"[INFO] Retrying in {RETRY_DELAY}s ...")
            time.sleep(RETRY_DELAY)
    raise RuntimeError(f"Failed to download after {retries} attempts: {url}")

def download_and_extract(url: str, target_dir: Path):
    os.makedirs(target_dir, exist_ok=True)
    data = download_with_retry(url)
    log(f"[EXTRACT] Extracting to {target_dir} ...")
    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        zf.extractall(target_dir)
    log(f"[OK] Extraction complete.")

def is_llama_server_present() -> bool:
    """bin 폴더에 llama-server.exe 또는 server.exe가 있으면 True"""
    for name in ("llama-server.exe", "server.exe", "llama-cli.exe"):
        if (BIN_DIR / name).exists():
            return True
    return False

# ── venv 생성 ────────────────────────────────────────────────────────────────

def ensure_venv() -> bool:
    if PYTHON_VENV.exists():
        # 기존 venv가 현재 Python과 호환되는지 확인
        try:
            res = run_cmd([str(PYTHON_VENV), "--version"], capture=True)
            ver_line = (res.stdout or res.stderr or "").strip()
            log(f"[INFO] Existing venv Python: {ver_line}")
            return True
        except Exception:
            log("[WARNING] Existing venv seems broken. Recreating...")
            shutil.rmtree(VENV_DIR, ignore_errors=True)

    log("[INFO] Creating virtual environment at: venv_win")

    # venv 생성 시도: 현재 Python 사용
    try:
        res = run_cmd([sys.executable, "-m", "venv", str(VENV_DIR)], check=False)
        if res.returncode == 0 and PYTHON_VENV.exists():
            log("[OK] venv created successfully.")
            return True
    except Exception as e:
        log(f"[WARNING] venv creation with {sys.executable} failed: {e}")

    # virtualenv 폴백
    log("[INFO] Trying 'virtualenv' as fallback...")
    try:
        run_cmd([sys.executable, "-m", "pip", "install", "--quiet", "virtualenv"])
        res = run_cmd([sys.executable, "-m", "virtualenv", str(VENV_DIR)], check=False)
        if res.returncode == 0 and PYTHON_VENV.exists():
            log("[OK] venv created via virtualenv.")
            return True
    except Exception as e:
        log(f"[ERROR] virtualenv fallback failed: {e}")

    log("[ERROR] Cannot create virtual environment.")
    return False

# ── pip 업그레이드 ────────────────────────────────────────────────────────────

def upgrade_pip():
    res = run_cmd(
        [str(PYTHON_VENV), "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"],
        check=False
    )
    if res.returncode != 0:
        log("[WARNING] pip upgrade had non-zero exit. Continuing anyway.")

# ── PyTorch 설치 ──────────────────────────────────────────────────────────────

def install_pytorch(backend: str):
    index_url = PYTORCH_INDICES.get(backend, PYTORCH_INDICES["cpu"])
    log(f"[INFO] Installing PyTorch for backend: {backend} (index: {index_url})")
    pkgs = ["torch", "torchvision", "torchaudio"]

    # 이미 설치 여부 확인
    try:
        res = run_cmd(
            [str(PYTHON_VENV), "-c", "import torch; print(torch.__version__)"],
            capture=True, check=False
        )
        if res.returncode == 0 and res.stdout.strip():
            log(f"[INFO] PyTorch already installed: {res.stdout.strip()}. Skipping reinstall.")
            return True
    except Exception:
        pass

    res = run_cmd(
        [str(PIP_VENV), "install"] + pkgs + ["--index-url", index_url],
        check=False
    )
    if res.returncode != 0:
        log("[WARNING] PyTorch install with CUDA failed. Trying CPU fallback...")
        res = run_cmd(
            [str(PIP_VENV), "install"] + pkgs + ["--index-url", PYTORCH_INDICES["cpu"]],
            check=False
        )
    return res.returncode == 0

# ── requirements.txt 설치 ────────────────────────────────────────────────────

def install_requirements():
    req_file = PROJECT_DIR / "requirements.txt"
    if not req_file.exists():
        log("[WARNING] requirements.txt not found. Skipping.")
        return True

    # 전체 설치 먼저 시도
    res = run_cmd(
        [str(PIP_VENV), "install", "-r", str(req_file), "--no-warn-script-location"],
        check=False
    )
    if res.returncode == 0:
        log("[OK] All requirements installed.")
        return True

    log("[WARNING] Bulk install failed. Trying package-by-package...")
    failed = []
    with open(req_file, encoding="utf-8") as f:
        lines = [l.strip() for l in f if l.strip() and not l.startswith("#") and not l.startswith("-")]

    for pkg in lines:
        r = run_cmd(
            [str(PIP_VENV), "install", pkg, "--no-warn-script-location"],
            check=False
        )
        if r.returncode != 0:
            log(f"[WARNING] Failed to install: {pkg}")
            failed.append(pkg)
        else:
            log(f"[OK] Installed: {pkg}")

    if failed:
        log(f"\n[WARNING] The following packages could not be installed:")
        for p in failed:
            log(f"  - {p}")
    return len(failed) == 0

# ── llama.cpp 바이너리 다운로드 ───────────────────────────────────────────────

def download_llama_binaries(backend: str):
    if is_llama_server_present():
        log("[INFO] llama-server binary already exists in bin/. Skipping download.")
        return True

    assets = LLAMA_ASSETS.get(backend, LLAMA_ASSETS["cpu"])
    success = True
    for key, url in assets.items():
        try:
            download_and_extract(url, BIN_DIR)
        except Exception as e:
            log(f"[WARNING] Failed to download llama binary ({key}): {e}")
            if backend != "cpu":
                log("[INFO] Trying CPU-only llama binary as fallback...")
                try:
                    download_and_extract(LLAMA_ASSETS["cpu"]["exe"], BIN_DIR)
                except Exception as e2:
                    log(f"[ERROR] CPU fallback also failed: {e2}")
                    success = False
            else:
                success = False
    return success

# ── Jupyter 커널 등록 ─────────────────────────────────────────────────────────

def register_jupyter_kernel():
    kernel_name = "LLM-HandsOn-WinCUDA"
    display_name = "LLM Hands-On (Win CUDA)"

    # ipykernel 설치 확인
    res = run_cmd(
        [str(PIP_VENV), "install", "--quiet", "ipykernel"],
        check=False
    )

    res = run_cmd(
        [str(PYTHON_VENV), "-m", "ipykernel", "install",
         "--user", "--name", kernel_name, "--display-name", display_name],
        check=False
    )
    if res.returncode == 0:
        log(f"[OK] Jupyter kernel '{display_name}' registered.")
    else:
        log(f"[WARNING] Jupyter kernel registration failed. You may need to do it manually.")
    return res.returncode == 0

# ── 최종 검증 ────────────────────────────────────────────────────────────────

def verify_installation(backend: str) -> dict:
    results = {}

    # Python
    res = run_cmd([str(PYTHON_VENV), "--version"], capture=True, check=False)
    results["python"] = res.returncode == 0

    # PyTorch + CUDA
    test_code = (
        "import torch; "
        "print('PyTorch:', torch.__version__); "
        "avail = torch.cuda.is_available(); "
        "print('CUDA Available:', avail); "
        "print('Device:', torch.cuda.get_device_name(0) if avail else 'CPU only')"
    )
    res = run_cmd([str(PYTHON_VENV), "-c", test_code], capture=True, check=False)
    results["pytorch"] = res.returncode == 0
    if res.stdout:
        for line in res.stdout.strip().splitlines():
            log(f"  {line}")

    # transformers
    res = run_cmd(
        [str(PYTHON_VENV), "-c", "import transformers; print('transformers:', transformers.__version__)"],
        capture=True, check=False
    )
    results["transformers"] = res.returncode == 0
    if res.stdout:
        log(f"  {res.stdout.strip()}")

    # llama-server
    results["llama_server"] = is_llama_server_present()

    return results

# ── 진행 상황 추적 ────────────────────────────────────────────────────────────

_steps = []
_current_step = [0]

def start_step(name: str):
    _current_step[0] += 1
    section(f"Step {_current_step[0]}: {name}")

def record_step(name: str, ok: bool, note: str = ""):
    status = "✅ OK" if ok else "⚠️  WARN"
    _steps.append((name, ok, note))

# ── 메인 ─────────────────────────────────────────────────────────────────────

def main():
    init_log()

    log("=" * 56)
    log("  🚀 LLM Hands-On Environment Installer (Hardened)")
    log(f"     Python  : {sys.version.split()[0]}")
    log(f"     Platform: {platform.system()} {platform.release()} ({platform.machine()})")
    log(f"     Project : {PROJECT_DIR}")
    log("=" * 56)

    # ── 사전 검증 ─────────────────────────────────────────────
    start_step("Pre-flight Checks")
    if not check_python_version():
        sys.exit(1)
    check_disk_space(PROJECT_DIR, required_gb=8.0)
    backend = detect_cuda_version()
    log(f"\n[INFO] Selected backend: {backend.upper()}")
    record_step("Pre-flight", True)

    # ── venv 생성 ─────────────────────────────────────────────
    start_step("Create Virtual Environment")
    ok = ensure_venv()
    record_step("venv", ok)
    if not ok:
        log("[FATAL] Cannot continue without a virtual environment.")
        sys.exit(1)

    # ── pip 업그레이드 ──────────────────────────────────────────
    start_step("Upgrade pip / setuptools / wheel")
    upgrade_pip()
    record_step("pip upgrade", True)

    # ── PyTorch 설치 ────────────────────────────────────────────
    start_step(f"Install PyTorch ({backend})")
    ok = install_pytorch(backend)
    record_step("PyTorch", ok, backend)
    if not ok:
        log("[WARNING] PyTorch install failed. Some notebooks may not work.")

    # ── requirements.txt ────────────────────────────────────────
    start_step("Install Requirements (requirements.txt)")
    ok = install_requirements()
    record_step("requirements.txt", ok)

    # ── llama.cpp 바이너리 ──────────────────────────────────────
    start_step("Download llama-server Binary")
    ok = download_llama_binaries(backend)
    record_step("llama-server", ok)

    # ── Jupyter 커널 등록 ───────────────────────────────────────
    start_step("Register Jupyter Kernel")
    ok = register_jupyter_kernel()
    record_step("Jupyter kernel", ok)

    # ── 검증 ───────────────────────────────────────────────────
    start_step("Verify Installation")
    results = verify_installation(backend)
    for k, v in results.items():
        record_step(f"  verify:{k}", v)

    # ── 최종 요약 ──────────────────────────────────────────────
    log("\n" + "=" * 56)
    log("  📋 Setup Summary")
    log("=" * 56)
    all_ok = True
    for name, ok, note in _steps:
        icon = "✅" if ok else "⚠️ "
        extra = f"  ({note})" if note else ""
        log(f"  {icon}  {name}{extra}")
        if not ok:
            all_ok = False

    log("")
    if all_ok:
        log("  ✅ All steps completed successfully!")
    else:
        log("  ⚠️  Setup completed with some warnings.")
        log("     Please review the messages above.")

    log("")
    log(f"  Backend      : {backend.upper()}")
    log(f"  venv path    : {VENV_DIR}")
    log(f"  Kernel name  : LLM Hands-On (Win CUDA)")
    log(f"  Log file     : {LOG_FILE}")
    log("")
    log("  Usage: Open Jupyter and select kernel 'LLM Hands-On (Win CUDA)'")
    log("  Notebooks: 8_decoding ~ 14_langchain (venv_win kernel)")
    log("=" * 56)

    if _log_fh:
        try:
            _log_fh.close()
        except Exception:
            pass

    return 0 if all_ok else 1

if __name__ == "__main__":
    sys.exit(main())
